# "Facts and myths about Python names and values"

Esta série de notebooks foi criada a partir da adaptação do post de mesmo nome de Ned Batchelder.

* [Parte 01](ned/names-and-values-01.ipynb)
* [Parte 02](ned/names-and-values-02.ipynb)

### Disclaimer
* Autor: Leonardo Bezerra
